import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Respuesta } from 'src/app/model/respuesta';
import { VehiculoService } from 'src/app/service/vehiculo.service';

@Component({
  selector: 'app-vehiculo-cantidad',
  templateUrl: './vehiculo-cantidad.component.html',
  styleUrls: ['./vehiculo-cantidad.component.css']
})
export class VehiculoCantidadComponent implements OnInit {
  dataSource: MatTableDataSource<Respuesta> = new MatTableDataSource();
  displayedColumns: string[] = ['propietario', 'cantidad',];
  constructor(private vS:VehiculoService) { }

  ngOnInit(): void {
    this.vS.buscarcantidadvehiculos().subscribe(data=>{
      this.dataSource=new MatTableDataSource(data);
    })
  }

}

export class Respuesta{
    propietario:string="";
    cantidad:string="";
}
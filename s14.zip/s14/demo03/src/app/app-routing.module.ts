import { PropietarioDominioComponent } from './pages/propietario/propietario-dominio/propietario-dominio.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PropietarioEditarComponent } from './pages/propietario/propietario-editar/propietario-editar.component';
import { PropietarioComponent } from './pages/propietario/propietario.component';
import { VehiculoEditarComponent } from './pages/vehiculo/vehiculo-editar/vehiculo-editar.component';
import { VehiculoComponent } from './pages/vehiculo/vehiculo.component';
import { VehiculoCantidadComponent } from './pages/vehiculo/vehiculo-cantidad/vehiculo-cantidad.component';

const routes: Routes = [
    {
        path: 'propietarios', component: PropietarioComponent, children: [
            { path: 'nuevo', component: PropietarioEditarComponent },
            { path: 'edicion/:id', component: PropietarioEditarComponent },
            {path:'dominios',component:PropietarioDominioComponent}
        ]
    },
    {
        path: 'vehiculos', component: VehiculoComponent, children: [
            { path: 'nuevo', component: VehiculoEditarComponent },
            { path: 'edicion/:id', component: VehiculoEditarComponent },
            {path:'cantidades', component:VehiculoCantidadComponent}
        ]
    }
]

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule { }


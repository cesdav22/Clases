package pe.edu.upc.demo.entities;

public class Respuesta {
    private String propietario;
    private String cantidad;

    public Respuesta(String propietario, String cantidad) {
        this.propietario = propietario;
        this.cantidad = cantidad;
    }

    public Respuesta() {
    }

    public String getPropietario() {
        return propietario;
    }

    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }
}
